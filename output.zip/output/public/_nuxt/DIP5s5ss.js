import{bn as e,r as o,z as n}from"#entry";function u(r){const t=e({dir:o("ltr")});return n(()=>r?.value||t.dir?.value||"ltr")}export{u};
