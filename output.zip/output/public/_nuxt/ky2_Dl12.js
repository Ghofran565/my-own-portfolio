import{bm as r}from"#entry";function s(t,e="reka"){return`${e}-${r?.()}`}export{s as u};
