import{f as d}from"./BN_7HF1G.js";import{W as a}from"#entry";const w=(f,r,t,...n)=>f[r]?a({...f,[r]:()=>d(f[r](),t?.unwrap||t?.mdcUnwrap)},r,t,...n):a(f,r,t,...n);export{w as r};
